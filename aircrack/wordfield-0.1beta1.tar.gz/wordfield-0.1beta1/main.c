/*
 * wordfield - word list generator
 * 
 * Copyright (c) 2009 Vincent Wochnik
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
*/

#include <argp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <zlib.h>

#include "funcs.h"

const char *argp_program_version = "wordfield 0.1beta1";
const char *argp_program_bug_address = "<v.wochnik@yahoo.com>";
static char doc[] = "Program to create large amounts of words in few time.";
static char args_doc[] = "MINLENGTH [MAXLENGTH]";

static struct argp_option options[] = {
	{"verbose", 'v', 0, 0, "Print additional status information"},
	{"quiet", 'q', 0, 0, "Do not print status messages"},
	{"charset", 'c', "STRING", 0, "Set user defined char set. The maximum char set length is 255 chars."},
	{"letters", 'a', 0, 0, "Char set contain letters. Do not use this with the --charset option."},
	{"capitals", 'A', 0, 0, "Char set contain capital letters. Do not use this with the --charset option."},
	{"numbers", 'n', 0, 0, "Char set contains numbers. Do not use this with the --charset option."},
	{"specials", 's', 0, 0, "Char set contains special characters. Do not use this with the --charset option."},
	{"output", 'o', "FILE", 0, "Output to file instead of STDOUT."},
	{"gzip", 'g', "RATE", 0, "Produce gzipped output. You have to specify compression rate from 0 to 9."},
	{ 0 }
};

struct arguments
{
	/*
	 * Contains a pointer to the char set
	 */
	char *chrset;

	/*
	 * Contains 1 if char set wanted.
	 */
	char letters, capitals, numbers, specials;

	/*
	 * Contains the compression rate, else zero.
	 */
	char compression, rate;

	/*
	 * Contains a pointer to the output file name.
	 */
	char *output_file;

	/*
	 * Is set to 1 on quiet mode.
	 */
	char quiet, verbose;

	/*
	 * Contains the minimum and maximum word length.
	 */
	size_t minlen,maxlen;
};

static error_t parse_opt (int key, char *arg, struct argp_state *state);

static struct argp argp = { options, parse_opt, args_doc, doc };

int main (int argc, char **argv)
{
	int ret;
	wordfield *word = NULL;
	FILE *out = NULL;
	gzFile *gzout = Z_NULL;
	struct arguments args = { 0 };

	/* Parse command line arguments */
	argp_parse (&argp, argc, argv, 0, 0, &args);

	/* Initialize word field */
	word = wordfield_init (args.maxlen);

	if (word == NULL)
	{
		if (!args.quiet)
			fprintf (stderr, "Unexpected program error.\n");
		exit (1);
	}

	/*
	 * Copy char set into memory.
	 */
	if (args.chrset != NULL)
	{
		ret = validate_charset (args.chrset, strlen(args.chrset));
		if (ret != 0)
		{
			if (!args.quiet)
				fprintf (stderr, "Invalid char set.\n");
			exit (1);
		}

		ret = wordfield_set_charset (word, args.chrset, strlen(args.chrset));
		if (ret != 0)
		{
			if (!args.quiet)
				fprintf (stderr, "Could not load char set.\n");
			exit (1);
		}
	}
	else
	{
		if ((!args.letters) && (!args.capitals) && (!args.numbers) && (!args.specials))
			args.letters = 1;

		ret = wordfield_generate_charset (word, args.letters, args.capitals, args.numbers, args.specials);
		if (ret != 0)
		{
			if (!args.quiet)
				fprintf (stderr, "Could not generate char set.\n");
			exit (1);
		}
	}

	/* Open file with gz(d)open if compression used */
	if (args.compression)
	{
		int ret;
		char mode[8];

		ret = sprintf (mode, "w%d", args.rate);

		if (args.output_file != NULL)
			gzout = gzopen (args.output_file, mode);
		else
			gzout = gzdopen (fileno(stdout), mode);

		if (gzout == Z_NULL)
		{
			if (!args.quiet)
				fprintf (stderr, "%s\n", "Could not open file.");
			exit (0);
		}
	}
	else
	{
		if (args.output_file != NULL)
			out = fopen (args.output_file, "w");
		else
			out = stdout;

		if (out == NULL)
		{
			if (!args.quiet)
				fprintf (stderr, "%s\n", "Could not open file.");
			exit (0);
		}
	}

	while (1)
	{
		if (word->len < args.minlen)
			ret = wordfield_set_length (word, args.minlen);
		else if (word->len < args.maxlen)
			ret = wordfield_set_length (word, word->len+1);
		else
			break;

		if (ret != 0)
		{
			if (!args.quiet)
				fprintf (stderr, "Could not set word length.\n");
			exit (1);
		}

		do
		{
			ret = wordfield_generate (word);
			if (ret != 0)
			{
				if (!args.quiet)
					fprintf (stderr, "Could not generate char set.\n");
				exit (1);
			}

			if (args.compression)
			{
				gzputs (gzout, word->word);
				gzputc (gzout, '\n');
			}
			else
			{
				fputs (word->word, out);
				fputc ('\n', out);
			}

			ret = wordfield_increment (word);
		}
		while (ret == 0);
	}

	/* Free word field */
	wordfield_free (word);

	if (args.compression)
		gzclose (gzout);
	else if (out != stdout)
		fclose (out);

	exit (0);
}

static error_t parse_opt (int key, char *arg, struct argp_state *state)
{
	/* Get the input argument from argp_parse, which we
	   know is a pointer to our arguments structure. */
	struct arguments *args = state->input;

	switch (key)
	{
	case 'q':
		if (args->verbose)
			argp_usage (state);
		args->quiet = 1;
		break;

	case 'v':
		if (args->quiet)
			argp_usage (state);
		args->verbose = 1;
		break;

	case 'c':
		if ((args->letters) || (args->capitals) || (args->numbers) || (args->specials))
			argp_usage (state);
		if (strlen(arg) > 255)
			argp_usage (state);
		args->chrset = arg;
		break;

	case 'a':
		if (args->chrset != NULL)
			argp_usage (state);
		args->letters = 1;
		break;

	case 'A':
		if (args->chrset != NULL)
			argp_usage (state);
		args->capitals = 1;
		break;

	case 'n':
		if (args->chrset != NULL)
			argp_usage (state);
		args->numbers = 1;
		break;

	case 's':
		if (args->chrset != NULL)
			argp_usage (state);
		args->specials = 1;
		break;

	case 'o':
		args->output_file = arg;
		break;

	case 'g':
		args->compression = 1;
		errno = 0;
		args->rate = (char)strtoul (arg, NULL, 10);
		if ((errno) || (args->rate > 9))
			argp_usage (state);
		break;

	case ARGP_KEY_ARG:
		if (state->arg_num >= 2)
			argp_usage (state);
		switch (state->arg_num)
		{
		case 0:
			errno = 0;
			args->minlen = (size_t)strtoul (arg, NULL, 10);
			if (errno)
				argp_usage (state);
			break;

		case 1:
			errno = 0;
			args->maxlen = (size_t)strtoul (arg, NULL, 10);
			if (errno)
				argp_usage (state);
			break;
		}
		break;

	case ARGP_KEY_END:
		if (state->arg_num == 1)
			args->maxlen = args->minlen;
		else if (state->arg_num < 1)
			argp_usage (state);
		if ((args->minlen < 1) || (args->maxlen < 1) || (args->minlen > args->maxlen))
			argp_usage (state);
		break;

	default:
		return ARGP_ERR_UNKNOWN;
	}
	return 0;
}

